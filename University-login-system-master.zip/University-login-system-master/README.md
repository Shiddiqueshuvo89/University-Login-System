# University-login-system
I create a Login system where student can login and they can see their all informtaion.Such as result.Teacher also can use it.  
